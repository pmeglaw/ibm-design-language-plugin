# Carbon Next (v12) — direction, and what's actually shipping

## Source refresh — 2026-10-10

This targeted refresh supplements the September snapshots below; it does not
revalidate every roadmap claim, AI variant, component count or source-map entry.
The [release schedule](https://github.com/carbon-design-system/carbon/blob/main/docs/release-schedule.md),
checked on this date, still lists v11 as Active and v12 as Preview, with v12's
active-release date TBD. The latest published monorepo release checked was
[v11.118.0, October 7, 2026](https://github.com/carbon-design-system/carbon/releases/tag/v11.118.0).
Its package entries include `@carbon/react@1.118.0`, `@carbon/styles@1.117.0`
and `@carbon/themes@11.83.0`. These are separate package versions, not an
application lockfile or an instruction to upgrade. Recheck before later use.

### Preview flags do not create missing exports

The [v11.118.0 feature-flag contract](https://github.com/carbon-design-system/carbon/blob/v11.118.0/docs/feature-flags.md)
distinguishes React, Sass and Web Components availability. Components marked
**Migrated** in the v12 Storybook are not public exports of the published v11
package; enabling `enable-v12-release` does not expose them. Check the installed
exports, chosen variant and each required runtime/style flag. Do not add a
package, run a codemod or enable the umbrella flag merely to reproduce a preview.
Any authorized opt-in needs scoped behavior, visual and recovery checks.

### DTCG source is implemented, not a required consumer migration

The [v11.118.0 token-source documentation](https://github.com/carbon-design-system/carbon/blob/v11.118.0/packages/themes/src/dtcg/README.md)
records all four themes in `packages/themes/src/dtcg/themes.json`, with component
tokens in `components/*.json`. Read nested keys and the selected theme under
`$extensions["carbon.themes"]`; entries can be strings or `{ value, alpha }`
objects. Preserve opacity when resolving a color. Component-token files can also
use the documented legacy `org.carbon.alphaModifiers` map. A node can contain both
its own token and child tokens; do not flatten by blindly splitting every hyphen.

This is source lookup guidance, not a new application import path. Keep supported
Sass/CSS entrypoints, product-owned semantic aliases, theme/layer ownership and
approved brand mappings. Generated token files are build output, not a place to
patch product colors. Source format alone proves neither emitted CSS, rendered
contrast nor compatibility with the installed version. See [Context7 retrieval
and regression checks](context7-refresh.md) for the source receipt and limits.

## What IBM published

v12 is presented as a statement of direction, not a spec. The argument: interfaces are splitting into two kinds — generated on demand and reshaping to context on one side, stable and predictable on the other — and the system has to serve both. The design goal is **progressive disclosure by default**: reveal depth in sequence, surface the right action at the right time, and let hierarchy, contrast and motion work together so people spend less time orienting.

The whole release is anchored to one word — **guide** — which is the same verb the IBM Design Language has used for its ethos since the Noyes era. The reframing is why it matters now: in a generative system, to guide is no longer to arrange pre-built paths but to shape and constrain what can happen at all. Secondary actions and necessary complexity still exist; they must never be mistaken for the signal.

Six declared shifts:

| Shift | What it means |
|---|---|
| Visual expression | A new expression built on complexity waiting until it's useful |
| Motion | Promoted from micro-interaction polish to a structural instrument — showing where you are and connecting it to what comes next |
| Layouts | Ready-made modular blocks and compositions so teams and agents start with correct structure |
| AI readiness | The system indexed and queryable by coding agents, with encoded instructions, agent skills and guardrails |
| Tokens & theming | Industry-standard naming — in practice the DTCG spec and a `.tokens.json` format |
| Product-centered components | Carbon for IBM Products (21 components, 24 complex patterns) opening to the community |

## Declared versus shipped

Snapshot boundary: the table records the 2026-09-15 documentation claims, not the consuming application's release state. A 2026-09-30 live check of the linked Carbon Next page still describes v12 in future tense, but does not independently verify every table entry, count, package or feature flag. Inspect the target package and current release documentation before implementation.

The roadmap includes update dates and component/pattern counts; these are not a release date or a complete shipped specification. Verify the current package release and particular API before implementation. [Carbon Next](https://preview.carbondesignsystem.com/carbon-next), reviewed 2026-09-15.

| Thing | Status |
|---|---|
| v12 | Preview. Begin-active, maintenance and end-of-life all TBD. |
| v11 | Active since 2022-03-31, no announced move to maintenance. |
| Adoption | Incremental opt-in through the active release via `enable-v12-*` feature flags. |
| Token rename | DTCG adoption in progress, explicitly committed to backward compatibility and zero consumer impact. |
| Carbon for AI | **Already stable in v11** — AI label, AI token suite, AI chat, AI variants of 12 core components. |
| Carbon MCP | Public preview. Serves docs, code examples, charts and Labs to coding agents. |

## Flag names recorded in the earlier reference snapshot

Check which flags exist and their defaults in the target installed release. The list below is reference history, not a verified API contract for every version.

| Flag | Turns on |
|---|---|
| `enable-v12-release` | All v12 flags present in the installed package; not every preview component (see the dated refresh above) |
| `enable-v12-overflowmenu` | OverflowMenu rebuilt on Menu subcomponents |
| `enable-v12-dynamic-floating-styles` | Dynamic placement for Popover, Tooltip and similar |
| `enable-v12-tile-default-icons` | Default icons in ClickableTile; check the target package and codemod coverage |
| `enable-v12-tile-radio-icons` | Radio icons in RadioTile |
| `enable-v12-structured-list-visible-icons` | Visible selection icons in StructuredList |
| `enable-v12-toggle-reduced-label-spacing` | Tighter toggle/label gap |
| `enable-tile-contrast` | Improved tile contrast |
| `enable-dialog-element` | Native `<dialog>` under modal components |
| `enable-presence` | Components unmounted while closed, mounted on open |
| `enable-focus-wrap-without-sentinels` | Focus wrapping without sentinel nodes |

These flags change different things. Some add visible selection cues; others affect positioning, mounting, dialog behavior, or focus management. Evaluate each flag against its component, installed version, and task rather than inferring a shared visual effect.

## Version-aware preparation

Four things worth doing now rather than later:

1. **Keep a semantic token layer.** Map product meaning to available system roles through product-owned tokens. This limits application touchpoints when Carbon changes token names or formats, but migration still needs a value, state, and rendered-theme audit.
2. **Check existing supported compositions first.** Consider Carbon for IBM Products for grids, panels, tearsheets and page headers when its released package, peers and APIs fit the project. A roadmap promise does not justify waiting for an unavailable component, adding a dependency or replacing an established product shell.
3. **Treat motion as structure.** A move between levels should read as one continuous transition that tells you where you went, not several independent fades.
4. **If the product has an AI surface**, use Carbon for AI — the AI label, the explainability popover, and the AI token set — rather than a bespoke "magic" treatment.

## Carbon for AI: guidance and package boundary

The guidance identifies AI-generated content and provides explainability. Its visual metaphor uses light to distinguish actual AI presence. The AI label's current official guideline marks it stable; this does not establish that every listed AI variant, token or separate AI Chat offering exists in every framework/package. Read [AI presence and explainability](ai-explainability.md) for focused versus broad labels, overrides/revert and keyboard behavior; verify the consuming package before adopting the summarized design guidance below.

- **Use the AI label wherever AI generates content.** It's both the marker and the entry point to explainability.
- The explainability popover attached to the label is the first layer: a short, in-context explanation, with the option to go deeper.
- AI tokens ship inside the main Carbon themes — no separate theme or package. Components have the AI styling available via a mixin; in Figma it's a variable mode.
- Components with AI variants: checkbox, data table, date picker, dropdown, form, modal, number input, radio button, select, tag, text input, tile. When the AI label is on, the component takes the AI style but behaves normally.
- If a user overrides AI-suggested content, the component reverts to the default variant — and should offer a way back to the AI version.
- **Never use AI styling as decoration.** It exists to mark AI presence, and diluting it destroys the signal.
- Light spread is deliberately limited so glows never compromise contrast.

## The caution

Build v11 properly and opt into flags as they prove out. Designing against an undated roadmap is how products end up half-migrated to something that never shipped.
