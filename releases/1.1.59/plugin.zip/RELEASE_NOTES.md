# 1.1.59 Design handoff verification

The design handoff now exercises a storage-dependent send with browser storage denied before startup, checks the receipt against both views after reload, and repeats with storage available. For a productive heading, it records the computed size at phone and desktop widths against the intended fixed style.

# 1.1.58 Pictogram and illustration gradients

The typography and color skill and its shared palette reference now point to IBM’s asset-specific gradient specifications. Pictograms use a linear gradient at 45°. In a line-style illustration, IBM recommends applying the blend along the stroke. Color pairing and palette grades still follow the IBM Color page.

# 1.1.57 IBM typeface and brand color

The typography and color skill now links directly to IBM Design Language’s Typeface and Color pages. It covers Plex family and script selection, font features, equation typesetting, and how to choose a two-color gradient for artwork. The token reference corrects its attribution of gradient angle and shape. Product controls continue to use their approved action and state roles.

# 1.1.56 Carbon typography and color

The new `ibm-design-language:typography-and-color` skill brings type and color decisions together for designers and implementers. It pairs compact or reading text with the corresponding heading, shows how the four Carbon themes layer surfaces, and distinguishes link, state and status colors. It links to Carbon’s two foundation overviews and the plugin’s detailed token and implementation references.

# 1.1.55 Review layout changes at breakpoints

The shared layout guide now checks how much of the primary task stays visible across a responsive transition. Designers compare neighboring widths with the same content, height, state and scroll position, then judge whether newly visible context earns the space it takes. The check applies in both design and critique.

This is a local review technique. The archive and manifest identify the prepared candidate. Publication and installation have separate verification records.

# 1.1.54 Layout techniques in product UI

The design and critique workflows now use IBM’s layout techniques when arranging a screen: choose a repeatable structure, vary it when the content changes role, group related decisions with space, and lead from focal content to an answer or action. The shared guide distinguishes balanced asymmetry from layouts that need equal measures for comparison. It includes a review-queue example and checks for content growth, stacking and meaningful order.

The source record distinguishes IBM’s prose and four inspected illustration pairs from local product guidance. No IBM imagery is included in this change. No new model evaluation, eye-tracking study or product usability result is claimed.

Prepared against published 1.1.53. These notes record the candidate; publication, downloaded assets and destination installation require separate verification.

# 1.1.53 Quick craft pass

Release candidate prepared for PR #116. Published 1.1.52 remains the recovery
and installation target until publication and destination verification complete.
These preparation-time notes do not establish delivery.

Add an opening eight-prompt scan order to the taste reference: task/register,
hierarchy/action scope, density/alignment, type/detail, color/surfaces,
states/continuity, removal/retention, and evidence/priority. Link existing
guidance, including a direct failure/retry recovery destination.

Preserve all pre-existing taste sections and skill entry-point routing. The
quick pass retains applicable benchmarks, serious interaction/accessibility
checks and cross-view comparisons. It preserves approved brand roles,
supported component sizes, useful secondary actions and meaningful boundaries;
unavailable checks remain untested.

Only taste guidance, package version metadata and these release notes change
inside the plugin. Repository release metadata and the new 1.1.53 archive
identify this candidate. Dependencies, product code, fixture assertions,
validation rules and earlier frozen releases remain unchanged.

Faster retrieval is an editorial objective, not a measured result. No model
evaluation or new product/assistive-technology assessment accompanies this
change. Required CI, publication, downloaded assets, installation parity and
fresh skill discovery require separate evidence.

# 1.1.52 Fail-fast evaluator hashing

Unpublished release candidate prepared locally for PR #109. Published 1.1.51
remains the recovery and installation target. This candidate has not been
merged, published or installed.

Reject nonregular hash inputs before opening them. Use nonblocking and binary
open flags where supported, then validate the opened descriptor before reading
its bytes. A POSIX FIFO introduced between the initial check and opening is
rejected without blocking; binary-byte hashing and Windows long-path handling
are preserved.

Add a POSIX regression with a 10-second outer subprocess deadline. It covers an
undeclared generated FIFO alongside a valid declared artifact, failure-receipt
finalization, and replacement during open even when the pathname is restored.
Device-file rejection and binary-byte hashing have direct regression coverage.

Repository CI now runs the synthetic evaluator suite independently on Linux and
Windows, while retaining the release-integrity check. This workflow is outside
the plugin archive. Earlier frozen releases and historical evidence are unchanged.

This fix does not provide a universal deadline for growing regular files or all
filesystem races. Synthetic tests do not establish generated-product quality;
no model evaluation was run for this fix. Required CI must pass on the final
intended release commit before separately authorized publication. Installation
and destination verification remain separate operations.

# 1.1.50 Header image routing

Link the saved header images and the 29 October header observation record
directly from the `design-ui` entry point again, beside the composition
benchmarks route. In 1.1.49 these links moved one step away, into
`references/release-gates.md`. A 60-run research-step routing comparison of
1.1.48 and 1.1.49 (Claude Code, three runs per task) found that 1.1.49 header
runs still reached the header benchmark and acceptance checks but opened the
saved header images in 0 of 3 runs, compared with 3 of 3 for 1.1.48.

The entry point grows from 16,348 to 16,524 bytes. No other guidance, links,
runtime assets, dependencies, product code, evaluation contracts or fixture
assertions change. Earlier frozen releases remain unchanged. The effect of this
change on routing and on generated output is evaluated separately and is not
established by these notes.
Publication and destination installation require separate verification.

# 1.1.49 Lighter design-ui entry point

Move the header, data table, search and form benchmark routing from the
`design-ui` skill entry point into a Composition benchmarks section of
`references/release-gates.md`, so it loads only when one of those compositions
is in scope. Replace the grouped routing table with one row per reference and
route the semantic token example directly. The entry point shrinks from about
18.9 KB to 16.3 KB; benchmark wording, links and guidance are otherwise unchanged.

The repository verifier now also checks that Markdown heading anchors in packaged
links resolve. No runtime assets, dependencies, product code, historical
evaluation contracts or fixture assertions change. Earlier frozen releases remain
unchanged. No model evaluation was run for this restructuring, so its effect on
skill routing and generated output is untested.
Publication and destination installation require separate verification.

# 1.1.48 Table navigation and action guidance

Separate collection navigation (pagination, load more and continuous browsing)
from virtualization as a rendering strategy. Preserve frequently used secondary
actions, with overflow reserved for less frequent contextual commands.

Add scoped acceptance guidance for selection across rendered windows, navigation
recovery, keyboard/focus behavior and action discovery. Distinguish semantic
tables from interactive grids and respect batch-mode action restrictions.

No runtime assets, dependencies, product code, historical evaluation contracts
or fixture assertions change. Earlier frozen releases remain unchanged.
Static guidance regressions and existing browser fixtures do not establish
model-generated product quality or assistive-technology certification.
Publication and destination installation require separate verification.

# 1.1.47 Reference spacing corrections

Restore missing spaces between words and numbers in shipped reference text, such
as `All17supplemental`, `with75nodes`, `React1.117.0` and `September2026`. The
change inserts spaces only: no wording, values, links, code spans, identifiers
or line endings change. Component and token identifiers such as `Context7`,
`Notification20` and `HTTPError403` are unchanged.

No product code, dependencies, runtime assets or fixture assertions change.
Seat Planner remains unchanged. Frozen earlier releases and evidence are preserved.
No model-quality or assistive-technology certification is claimed. Publication and
installation require separate verification.

---

# 1.1.46 Stable Carbon Sass warning fix checks

Extend the Sass/token deprecation checklist with live stable-release and transitive
dependency comparisons, published-source verification, comparable non-mutating
compilation probes and evidence-qualified upgrade recommendations. Distinguish
stable fixes from previews and unreleased changes, and warning suppression from
actual remediation. Main-skill intake routes to these checks.

No product code, dependencies, runtime assets or fixture assertions change.
Seat Planner remains unchanged. Frozen earlier releases and evidence are preserved.
No model-quality or assistive-technology certification is claimed. Publication and
installation require separate verification.

---

# 1.1.45 Carbon Sass and token deprecation checks

Extend the framework checklist and main-skill routing with version-qualified
Sass/token API checks, custom-property provenance, in-memory diagnostic compilation,
complete warning-trace attribution, suppression limits and separate application,
upstream and unresolved outcomes. Preserve supported APIs and approved brand roles;
require actual evidence before recommending migration or dependency changes.

Includes the existing 1.1.44 review-wording refinements unchanged. Its frozen
preparation notes retain their original unpublished wording; actual publication
belongs to the immutable release record. No product code, dependencies, runtime
assets or fixture assertions change. Seat Planner remains unchanged. Earlier
frozen packages and evidence are preserved. No model-quality or AT certification
is claimed. Publication and installation require separate verification.

---

# 1.1.43 Carbon React deprecated import and prop checks

Extend the framework deprecation checklist and main-skill routing with
version-qualified Carbon React import and prop checks. Cover public exports,
aliases/wrappers/spreads, declaration and runtime deprecations, unresolved-type
coverage gaps, actual usage, replacement evidence and behavior verification.
Distinguish valid v11 APIs from future-major migration and report no-action
outcomes explicitly.

No product code, dependencies, runtime assets or fixture assertions change.
Seat Planner remains unchanged. Earlier frozen packages and evidence are
preserved. No model-quality or assistive-technology certification is claimed.
Publication and installation require separate verification.

---

# 1.1.42 IBM Products deprecation and migration checks

Extend the framework deprecation checklist and main-skill routing with
version-qualified IBM Products checks: package versus component/prop status,
peer compatibility, actual usage, preview import naming, planned core-v12 moves,
composable replacements, CSS ownership and application-owned behavior checks.
Distinguish immediate remediation from future migration and verify current
release/export availability before recommending changes.

No product code, dependencies, runtime assets or fixture assertions change.
Seat Planner remains unchanged. Earlier frozen packages and evidence are
preserved. No model-quality or assistive-technology certification is claimed.
Publication and installation require separate verification.

---

# 1.1.41 Carbon deprecation checklist

Add a dated, source-linked deprecation checklist to framework guidance and route
implementation intake to it from design-ui. Cover legacy package replacements,
v10 Elements, framework-specific icons, React support boundaries, resolved
lockfiles, stylesheet ownership and historical tutorial examples. Require current
release/peer verification and authorized, tested migrations; do not infer v12
availability or today's latest React version from the notice.

No dependency, product code, runtime asset or fixture assertion changes. Fixture
checks establish regressions only; no new model or assistive-technology evaluation
is claimed. Publication and destination installation require separate verification.

---

# 1.1.40 UI shell observation reference

Add the dated 29 October 2026 observation of Carbon React's Navigation and
Actions story: desktop geometry, typography, hover/tooltips, dropdown, demo
content/modal, responsive boundaries, hamburger, side navigation and nested links.
Route design-ui and UI shell guidance to the reference and record source scope.

Keep observations separate from universal specifications: exclude Storybook
outlines, do not promote transition samples to tokens, retain deployed-version
uncertainty, and flag the 320px utility clipping and constrained phone content.
No product code, runtime assets, dependencies, fixture assertions or historical
evidence change. No model evaluation, touch/keyboard/AT or full-theme pass is
claimed. Publication and destination installation are verified separately.

---

# 1.1.39 Restoration of 1.1.37 content candidate - unpublished

Restore the complete 1.1.37 skill, guidance and runtime-asset content at the
owner's request following reported dissatisfaction with 1.1.38 design output.
Five reference files return to their exact 1.1.37 bytes; all 21 files introduced
by 1.1.38 are removed from the current package. All 175 files under skills/
match the frozen 1.1.37 release. The three skill identities remain unchanged.

The account update flow requires an increasing semantic version, so this
restoration uses 1.1.39. The version and this release-note prefix are the only
payload differences from the restored behavior; the previous release notes,
archives, manifests, tags and evaluation evidence remain preserved.

This change does not implement the gap-remediation plan. It does not change
product code, dependencies, evaluator assertions or fixture behavior. Routine
restoration requires package, fixture and delivery verification but no new
model evaluation; restored content is not a measured claim of improved output.

This is an unpublished restoration candidate. Publication, downloaded-asset
verification, the existing account update and fresh discovery are separate
steps recorded in current companion documentation. Earlier notes below retain
their exact bytes and original evidence limits.

# 1.1.38 Carbon-rendered anatomy examples candidate - unpublished

Supplement the static design-ui casebooks with 16 controlled local captures
of real Carbon React 1.117.0 table, form, header and search components.
White/Gray 100 and 1440px/390px viewport examples include provenance records,
image/source/font hashes and explicit differences from the fictional studies.
The repository fixture gains a dedicated screenshot command; reviewed images
are promoted manually rather than overwritten automatically.

All three skill identities/frontmatter blocks, sibling entrypoints, runtime
assets, dependencies, evaluator assertions and earlier release bytes remain
unchanged. Fixture content and demonstration behavior are preserved.
These are related anatomy examples, not official IBM exemplars, functioning
product workflows, keyboard/AT certification or model-generation evidence.

This is an unpublished candidate prepared for draft-PR review. Merging,
tagging, publication, installation and marketplace updates are separate.
Earlier notes below retain their exact bytes and original evidence limits.

# 1.1.37 Expressive and desktop composition references candidate - unpublished

Add focused local playbooks for expressive/hybrid surfaces and selected Gallery
studies, IBM marks/app icons, illustration/photography, creative animation,
infographic/chart selection and desktop composition craft. Connect these through
design-ui routing and the color, composition and taste references. Keep source
summaries separate from labeled local heuristics and retain partial coverage.

All three skill names and frontmatter blocks, both sibling entrypoints,
executable assets, dependencies and evaluator assertions remain unchanged.
Existing release archives, evaluation records and historical scores are preserved.
Only three selected static Gallery images add visual source observations; no new
product runtime, theme matrix, AT pass, model evaluation or regrading is claimed.
No narrow/RTL remediation, Seat Planner skill change or migration is included.

This is an unpublished local release candidate. Publication, installation and
marketplace updates are separate actions. Earlier notes below retain their
preparation-time wording and limits.

# 1.1.36 IBM Products migration references candidate - unpublished

Refresh only carbon-next.md, composition.md and source-map.json with the
reviewed IBM Products 2.101.0/v12 migration-documentation snapshot. Distinguish
the existing composable PageHeader preview in IBM Products from its planned
stable Carbon-core delivery at v12. Qualify legacy/composable APIs, SidePanel,
TagSet and card migration routes without treating roadmap notes as released
target exports, available codemods or authorization to migrate an application.

All three SKILL.md entrypoints, executable assets, dependency manifests,
evaluation criteria and existing gates remain unchanged. Earlier source-map
entries, historical notes, results and frozen release bytes are preserved.
This is reference preparation, not evidence of migration compatibility,
improved model behavior or generated-product quality.

Published and installed 1.1.35 remain unchanged. The loading experiment stays
parked. No new model experiment, release or installation is part of this work.

# 1.1.35 Compact reference catalog candidate - unpublished

Shorten only design-ui's Reference routing section into eleven grouped routes.
Preserve all 51 destination occurrences, component-name lookup cues, topic
coverage and the reference-routing anchor. Every instructional byte outside
that section and both companion skills remains unchanged.

The catalog decreases from 6,909 to 6,437 UTF-8 bytes; the complete entrypoint
decreases from 17,171 to 16,699 bytes (472 bytes, 2.75%). This is a measured
static instruction-size reduction, not evidence of reduced model context use,
removed truncation warnings, improved triggering or better behavior.

Published and installed 1.1.34 remain unchanged. The loading experiment stays
parked; no model experiments or historical regrading are part of this candidate.
Existing frozen releases, runtime assets, dependencies, assertions and gates
are preserved. This is unpublished preparation, not release or installation.

# 1.1.34 Focused guidance and contextual examples candidate - unpublished

Apply three reviewed wording clarifications in two guidance files:

- Put Focused guidance first in mode selection and make its precedence over
  composition benchmark/gate reading explicit for focused questions. Preserve
  applicable component and accessibility contracts.
- Describe dashboard priority placement through the intended reading order and
  writing direction instead of a fixed physical corner.
- Make create-flow validation task-dependent and explain unmet requirements
  accessibly when Next is disabled.

The exact wording received independent source/evidence review with no actionable
findings. Behavioral effectiveness, loading and context-cost effects remain
unverified. No new model evaluation, generated-product verification or
assistive-technology test is established by this preparation. Earlier scores,
failures and evidence limits retain their original scope.

This is an unpublished candidate. Published and installed 1.1.33 remain unchanged.
Descriptions, companion skill guidance, runtime assets, dependency manifests,
evaluation assertions and existing release/browser gates are preserved.
Publication and installation require separate authorization and verification.

# 1.1.33 Design-deliverable retention candidate - unpublished

Keep the requested critique or redesign deliverable primary across the requested
surfaces, including a visual proposal when requested. Record discovered bugs
separately and assess whether their implementation survives or is superseded by
the proposed direction. Require the owner's scoped choice before repair-only
work replaces the design task; reuse valid prior approval and honor explicit
repair-only tasks and justified no-change recommendations.

The two entrypoints and separate four-scenario specification exactly match the
reviewed candidate. Reused response-only evidence: five baseline and five
candidate samples each met 20/20 criteria; three candidate controls met 9/9;
two later three-turn controls met 5/5 and 4/4 under independent grading. The baseline
also passed, so no behavioral advantage is established. One known sample per
later control, unavailable exact collaboration model ID and missing full
tool-event review limit reliability and execution claims. No new model calls
during versioned preparation. Original suites and scores stay frozen.

This is unpublished preparation only. Published and installed 1.1.32, older
frozen bytes, runtime assets, dependencies and gate assertions remain unchanged.
No commit, push, merge, tag, release, account update, reinstall or production
action. See the companion design-focus evaluation ledger.

# 1.1.32 Seat Planner contract-discovery and safeguards candidate - unpublished

Integrate the exact reviewed external candidate: discover supplied project
contracts before reporting them unavailable, update the bundled baseline to
the approved all-width/200% zoom admin-editing policy, and explicitly report
current safeguards for production actions whose prior authorization survives.
The two skill-content files match the frozen evaluated candidate byte-for-byte;
all other skill files are unchanged from prepared 1.1.31.

Reuse 70/70 known-regression criteria across two packets for cases 101-104 and
201-208 under gpt-6.1-sol / medium; no new model calls. Historical failures and
incomplete results remain intact. Original cases 1-10 are NOT RUN on this exact
candidate. Single unblinded samples and source/synthetic SQL do not establish
causal improvement, general reliability, browser/real Auth/production behavior,
native installed discovery or generated-product quality.

This is unpublished source/preparation only. Preserve published/installed 1.1.30,
frozen 1.1.31 and all older artifacts, data, account configuration and security
policy. No merge, tag, release, account update, reinstall or deployment.

# 1.1.31 Seat Planner authorization correction candidate - unpublished

Integrate the reviewed production-action paragraph into seat-planner-ui-ux.
Require explicit consequences, specific owner authority and applicable current
safeguards, including refusals and deferrals; reuse valid prior approval, clarify
ambiguous assent and continue independent work. No other skill content changes.

The skill file exactly matches the externally evaluated safeguards candidate.
Reused known-regression evidence covers independent cases 201-208 (46/46 criteria)
and authorization cases 101-104 (24/24), across separate single-sample runs with
gpt-6.1-sol / medium. Historical failures, incomplete attempts and recovered tool
errors remain recorded in PR #47's companion ledgers. No new model call or claim
of causal improvement, repeatability, native discovery or generated-product QA.

Published/installed 1.1.30, production and retained data, security policy, frozen
earlier archives and existing gates remain unchanged. This is source/preparation
only: no merge, tag, release, installation, account update or deployment. Original
cases 1-10 on this exact candidate, browser/button, real Auth, accessibility and
production behavior remain unverified. Publication requires separate authority
and completion of applicable release gates and destination verification.

# 1.1.30 Context7 reference refresh candidate - unpublished

Add version-aware Context7 discovery, official-source reconciliation,
bounded fallback, privacy and permission boundaries. Refresh the dated
Carbon v11.118.0/package-version receipt, v12 Migrated-component export
boundary and consolidated DTCG token-source lookup. Add release-derived
review scenarios for SideNav, forced-colors inputs, DataTable selection
and CodeSnippet keyboard stops. These scenarios are guidance, not
executed application or assistive-technology tests.

Preserve the approved three-file refresh from PR #45, all three skills,
runtime assets, fixture assertions, dependencies and historical evidence.
No Carbon upgrade, v12 opt-in, Seat Planner change or new model evaluation
is included. Previous release bytes remain unchanged.

This is an unpublished preparation record. Final candidate verification
is recorded in PR #45; publication and installation require separate
approval and evidence. Do not infer either from archive preparation.

# 1.1.29 Seat Planner UI/UX candidate - unpublished

Add the approved dedicated seat-planner-ui-ux skill alongside design-ui and
review-product-experience. A bare UI/UX run defaults to read-only review;
implementation requires scoped authorization and current repository contracts.
The bundled project baseline does not override later approved product decisions.

Preserve the three approved source files from PR #43, both existing IBM skills,
runtime assets, fixture assertions, prior releases and historical evidence.
The ten authored scenarios remain not_run. They are a future agent-behavior
scenario specification, not an input packet for the existing evaluator.
No fresh model generation, product UI verification or manual assistive-technology
evaluation is claimed. Package and model-free fixture checks are separate.

Publication, downloaded-byte verification, account update, local installation
parity and fresh discovery remain pending until each is separately verified.

# 1.1.28 validation fixes candidate - unpublished

Reject empty or malformed contrast JSON batches before emitting any results.
Preserve contrast thresholds and valid-input exit codes. Require explicit
visual_dimensions in custom evaluation cases during preparation, before any
model launch; [] remains valid for cases without visual scoring.

The companion installation verifier recognizes the exact skills-only Codex upload
compatibility manifest separately from release bytes. Unexpected metadata,
identity changes, alternate skill paths, symlinks and release drift still fail.
Add CLI, preparation and installation regressions, and document the contracts.

This candidate preserves previous releases and historical evaluation results.
No fresh model generation or manual assistive-technology evaluation is claimed.
Publication and destination installation remain pending until separately verified.

# 1.1.27 header reference candidate - unpublished

Refresh the packaged UI shell header reference from the Carbon Guidelines,
Specifications, Code and Accessibility pages marked updated October 2, 2026,
reviewed October 6. Add current variant-to-Storybook routing, geometry and
typography, semantic state roles, naming and responsive rules, and accessibility
composition responsibilities. Preserve historical receipts and framework/version
boundaries. Storybook identifies @carbon/react@1.117.0; six selected overview APIs
and three White desktop compositions were inspected.

Bundle 21 original Carbon/IBM header illustrations with an index, source URLs,
dimensions, byte lengths and SHA-256 hashes, including the skip-link GIF and its
static fallback. Exclude site decoration and framework logos. The contact-sheet
review inspected only the GIF's first frame. Existing application code, fixture
assertions, historical releases and installed caches remain unchanged.

This is source and example inspection, not generated-product, keyboard, reflow,
assistive-technology or accessibility certification. Placeholder Storybook routes,
demonstration arguments and experimental badges are not stable product contracts.
Publication, exact-commit CI, supported installation and fresh discovery remain
pending. Record local verification in the task report; no published release claim
is made by preparing this archive.

# IBM Design Language 1.1.26 candidate - unpublished

Version 1.1.26 is an unpublished combined candidate. It restores the missing 1.1.24 package release-note entry and corrects the repository's stale publication note. It routes design and critique of header, table, search and form compositions to geometry and keyboard gates, with unchanged check definitions bundled for offline installed use. The menu-first keyboard condition is fixture-local; product shells preserve their first-focusable skip link. Evaluation packets now preserve both sibling skills, fingerprint both trees and validate local reference dependencies. Escaped Markdown link openings remain literal text; ordinary and even-backslash link openings retain dependency validation. Published archives, shell examples, fixture assertions, Missed patterns, evaluation suites and frozen evidence remain unchanged. Synthetic evaluator tests and fixture/example checks are not fresh model-generation or screen-reader results; the frozen 1.1.23 practical verdict remains 9 pass, 2 fail.

## Earlier release notes

Version 1.1.25 restores the Theme tokens Markdown table separator and adds scoped engineering craft checks for touch/hybrid hover, font-display choices, measured critical font preloads and language-safe subsetting. The guidance preserves supported Carbon behavior, native activation, focus/state feedback and the approved font-loading pipeline. It does not change runtime assets, component APIs, evaluation assertions or historical verdicts. No fresh model generation, product font-performance test or manual screen-reader evaluation was performed for this documentation release.

Version 1.1.24 focuses the maintained Next.js shell on the visible destination H1 after a committed route change and on same-route selection. Main is the fallback. Ordinary skip-to-main uses Next.js-integrated history, so Back does not restore a fragment URL over stale route content. Modified clicks stay native. A production-build shell gate covers heading focus, fallback, Back/Forward, and repeated skip. The release-fixture Node types setup was corrected without changing assertions or the Missed pattern. These checks are example and fixture evidence, not a new model-generation result or a screen-reader certification. Delayed or streaming headings remain the product's focus manager. The frozen 1.1.23 practical verdict remains 9 pass, 2 fail.

Version 1.1.23 adds an explicit Form visual benchmark using the owner-selected Carbon Guidelines and Web Components Default story, routed from design-ui and its taste rubric. It teaches label/input/help alignment, field grouping, default/fluid composition and final action placement. It records the Guidelines' 32px default column gutter versus a measured 16px demo pair, qualifies the story's selective xs support, and updates the historical read-only note. Live story controls are kept separate from released APIs and React submission behavior. Visual reference inspection and bounded retrieval checks do not establish application behavior, accessibility or generated-design quality; historical evaluations and frozen releases remain unchanged.

Version 1.1.22 adds an explicit Search visual benchmark, routed from design-ui and its taste rubric, using the owner-selected Carbon Search Guidelines and React Search overview. It teaches field silhouette, magnifier/text alignment, clear-control space, variant choice and placement through labeled craft correction pairs. Inspected React 1.117.0 and styles 1.116.0 confirm xs/sm/md/lg support at 24/32/40/48px, correcting the earlier three-height summary. Approved branding and historical evaluations remain intact. Bounded reference inspection and retrieval review do not establish generated-UI quality, all-size runtime geometry or accessibility.

Version 1.1.21 adds an official data table visual benchmark, routed from design-ui and its taste rubric, using the owner-selected Carbon Guidelines and React Basic overview. It teaches column alignment, density, restrained boundaries, action placement and long-content handling through labeled craft correction pairs. It reconciles conflicting toolbar sizing prose with inspected React/style package support, distinguishing the medium design recommendation from the React large default. Approved branding, component authority and historical evaluations remain intact. Reference inspection and bounded retrieval review do not establish improved generated UI, runtime toolbar geometry or accessibility.

Version 1.1.20 adds an explicit UI shell header visual benchmark, routed from design-ui and its taste rubric, using the owner-selected Carbon Guidelines and React Storybook. It teaches compact full-width composition, identity/navigation hierarchy, contiguous utilities and shell-versus-page action placement through labeled craft correction pairs. Approved branding, semantic themes, installed-version authority and separate behavior verification remain intact. Live reference inspection and bounded local retrieval review are not a generated-UI quality or accessibility evaluation. Prior evaluation verdicts remain unchanged.

Version 1.1.19 renames the main skill from `ibm-design-language` to `design-ui`, so its Codex mention is `ibm-design-language:design-ui`. The plugin identity remains `ibm-design-language@jp-personal`; the sibling `review-product-experience` skill keeps its name. Existing prompts using the old skill mention must use the new name. Skill instructions, assets, evaluation assertions and historical evidence are preserved. Only skill identity, paths and release metadata change. No new model generation or product usability/accessibility evaluation was run.

Published 1.1.17 strengthens real navigation destinations, observable supporting-action outcomes, nested narrow/RTL sizing, code scroll-owner keyboard checks and post-commit async focus recovery. Its fresh known practical generation failed with 9 pass, 2 fail and 0 untested; 320px containment/RTL remain deferred. Tested 390px and 1920px layouts fit. See [evaluation history](skills/design-ui/references/evaluation-history.md#published-1117-practical-regression) for exact snapshot identity and limitations.

Version 1.1.18 refines agent entrypoint/routing, task-scaled review, source-review freshness and the Chrome-native scroll focus evidence boundary. These documentation edits have no new generation score. The prior practical result belongs to published 1.1.17; its historical ZIP and manifest remain unchanged. Package, CI, downloaded asset and installation checks are separate from behavioral evidence.

Version 1.1.15 introduced the sibling review-product-experience skill for IA/UI/UX review. Both skills preserve Carbon authority, approved product branding and separate source, rendered, assistive-technology and model-evaluation evidence. Structural/package tests are not product usability or accessibility certification.
