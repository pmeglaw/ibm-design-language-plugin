# Evidence-graded skill evaluation

The suite is a regression set, not an expert certification. Preparing packets and scoring supplied reviews run locally. The Run action calls Codex and consumes model usage; run only cases authorized for the current evaluation.

## Four actions

Use Python 3.11+ and the installed Codex CLI. The PowerShell wrapper offers the same actions through -Mode Prepare, Run, Score, or Report. Its default is Prepare; there is no Force/reuse shortcut.

1. **prepare:** Supply --results-root (a new directory), --model, --reasoning, and optionally --ids. The default skill is this script's parent skill directory; --skill-root selects another candidate. --suite can supply the same reconciled suite to baseline and revised skills. --context-file can be repeated for relevant AGENTS/configuration inputs.
2. **run:** Supply the prepared --results-root and optional --ids. --timeout bounds each case; --codex selects an executable path. Failed or interrupted attempts remain recorded; create a fresh packet for another attempt.
3. **score:** After independent review, supply --results-root, --case-id, and --review. Copy the generated review.template.json to review.json, identify the reviewer and method, and record judgments and evidence.
4. **report:** Supply --results-root to aggregate scores. Unrun, failed, ungraded, and incomplete cases never count as passes.

Use scripts/evaluate.py --help and each action's --help for exact arguments. Example PowerShell invocation after choosing a supported model:

    python -B -X utf8 scripts/evaluate.py prepare --results-root C:/evaluation/run-01 --model MODEL_ID --reasoning high --ids 1 5 10 20 21

MODEL_ID is an example parameter to replace, not a prescribed model. Choose the same supported model/settings when comparing versions. The --model, --json, --output-schema, --output-last-message, and --ephemeral interface is documented in [Codex developer commands](https://learn.chatgpt.com/docs/developer-commands#codex-exec); verify the installed CLI's help when it changes.

## Identity and boundaries

Each packet snapshots the exact skill files and stores file hashes, suite hash, harness hash, selected cases, explicit model/reasoning, platform, Python version, and declared context-file hashes. Existing user config is fingerprinted without copying its contents. Run records the CLI version and exact argument list.

The exact entrypoint is embedded in the request, and supporting references are routed to the snapshot's absolute path. No ambiguous short-name invocation is used. The response identifies the supplied fingerprint. This proves which entrypoint was delivered and detects mismatched artifacts; it cannot prove exclusive mental reliance or eliminate all inherited host context.

Host policies still apply. No credentials, permission bypasses, or global skill configuration changes are needed. The case workspace is the intended write scope, while supporting snapshots are outside it. The harness does not create an operating-system boundary beyond the CLI sandbox. Include relevant policy/config files as context inputs and disclose uncontrolled differences.

The fingerprint algorithm hashes canonical JSON maps of relative paths to SHA-256 values. Git metadata, Python caches, node_modules, and .next are excluded. These exclusions are not permission to ignore relevant application dependencies: record lockfiles and test environments. An unavailable CLI or blocked sandbox remains a failed/unrun evaluation, never a pass.

## Review contract

Every assertion must appear exactly once with pass, fail, not_tested, or unreviewed. A scored pass or failure needs an evidence list. Each item contains a path relative to the case directory and a concrete observation. Accepted evidence locations are response.json, events.jsonl, stderr.txt, workspace/ artifacts, and evidence/ files.

Inspect actual output and behavior. The model's own checks are claims until independently verified. Use screenshots and browser notes for visual work, terminal logs for checks, and precise source observations where relevant. Add review evidence under evidence/ so the frozen generated outputs remain unchanged.

Visual artifact cases require integer scores 1–5 for every declared dimension and screenshot evidence under evidence/. A missing score is incomplete. Each dimension must reach 4; averaging cannot hide a weak dimension.

| Score | Anchor |
|---|---|
| 1 | Materially obstructs the task |
| 2 | Major problems require revision |
| 3 | Usable with clear design weaknesses |
| 4 | Coherent and polished; minor refinements remain |
| 5 | Exemplary result with convincing task-specific rationale |

Dimensions: hierarchy, layout, typography, color/imagery, and interaction clarity. A screenshot establishes appearance, not keyboard, assistive-technology, or backend correctness. Record those separately.

critical_findings is a list of evidence items for serious functional, accessibility, or scope failures. Any critical finding, failed assertion, or visual score below 4 fails the case. Missing judgments make it incomplete. Assertion percentage uses the full case denominator, including untested items.

## What scoring verifies

The scorer checks run/output identity, assertion coverage, evidence existence and hashes, rating bounds, and release thresholds. It detects edited outputs and stale review evidence. It does not automatically decide whether an observation is true, relevant, or well judged; the named reviewer remains responsible. Human review and authorized independent-agent review are both supported.

The supplied unit tests simulate CLI responses to validate harness behavior. They are not actual model evaluations and must never be reported as skill success rates.

## Remaining evaluation work

Run a baseline and candidate comparison with the same reconciled suite after approving model usage. Add the broader visual casebook and unseen practical benchmarks described in the source map before making an expert-readiness claim.
