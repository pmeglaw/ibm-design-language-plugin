# IBM Design Language and Carbon 1.1.4

Prepared: 2026-09-15 (America/Los_Angeles). Status: stable release package prepared locally; not installed or published.

## Release scope

Promotes the evaluated 1.1.4-rc.2 skill without changing any of its 35 skill files. Relative to rc.2, only plugin.json changes (version 1.1.4) and this release-notes file is added. The plugin contains 37 files.

## Changes from 1.1.3

- Shorter skill entrypoint with focused reference routing, source authority and explicit coverage limits.
- Preference for installed Carbon components and version-specific APIs; the optional standalone CSS fallback is documented as White/Gray 100 only, without JavaScript behavior.
- Clearer guidance for primary-action scope, empty tables, disabled/read-only states, accessible search names, motion, brand mappings and component-specific geometry.
- Fallback CSS corrections for closing easing, reduced motion and corner scope.
- A semantic-token worked example covering surfaces, text, links, primary-button interactions, focus and component-specific disabled roles.
- Source review that traces the winning component rule through its semantic role and verifies actual rendered paint and state changes.
- A source map and preserved component, pattern, typeface and 2x Grid navigation; coverage labels distinguish an index from verified implementation.
- Local evaluation preparation, execution, independent review and scoring tools. The bundled suite contains 21 cases. See the harness limitation below.

## Evidence supporting promotion

These are prior completed evaluations of rc.2, whose skill files are unchanged in 1.1.4. No new model runs were performed for release packaging.

| Separate comparison | rc.1 | rc.2 |
|---|---:|---:|
| API-key build: existing assertions | 8/10 | 10/10 |
| Theme switching: fixed assertions | 10/10 | 10/10 |
| Nested layers: fixed assertions | 10/10 | 10/10 |
| Disabled states: fixed assertions | 9/10 | 10/10 |

The API-key pair showed improved semantic-token consumption; both outputs passed the reviewed core flows. That rc.2 output still used a generic disabled-text role, an acknowledged refinement outside the broad rubric.

In the separate three-case comparison, rc.1 used a translucent Gray 100 disabled-button fill while rc.2 matched the frozen opaque role. rc.2 passed all 30 assertions; rc.1 passed 29. Visual dimensions tied at 4/5 for every output in both comparisons. These are small, non-blind samples with one run per case/version; the author also reviewed the results. They support a narrow token-fidelity improvement, not a general visual-quality or expert-readiness claim. Do not pool the different protocols.

The preceding repaired baseline-versus-rc.1 comparison tied at 19/20 assertions and 2/3 cases per version. It did not show an overall candidate advantage.

The unchanged worked example previously passed 285 browser assertions and 42 enabled-text contrast measurements in Chromium. These results are reused, not rerun during this packaging task. Release validation separately checks structure, local references, exact skill identity, both patches and archive bytes.

## Known limitations

- The bundled evaluator predates the separately repaired comparison harness. Snapshot-versus-entrypoint fingerprint wording, clearer billing/motion briefs, recorded per-case timeouts and separate preview ports were repaired outside this skill. The successful comparison runs used that repaired harness. Its 35 synthetic tests do not validate the older bundled evaluator. Use the separately delivered repaired method when reproducing these comparisons; integration into the skill requires a separate revision.
- Generated standalone prototypes do not establish installed Carbon React/Theme/Layer compatibility. The bundled fallback still implements only White and Gray 100; four-theme evaluation outputs were separately authored prototypes.
- The evidence does not certify screen readers, native 200% browser zoom, physical devices, other browser engines, backend integration, or IBM Plex font rendering where a fallback was used.
- IBM photography, illustration, logos, app icons, creative animation and a broader annotated visual casebook remain incomplete local coverage. Follow the skill's official source routes for those tasks.
- Stable is this package's version designation. It does not certify IBM/Carbon expertise or every bundled evaluation case.

## Evidence and provenance

Companion files in the delivery's outputs directory:

- ibm-design-language-1.1.4-release-review.md: final diff links, fresh package checks and commands.
- ibm-carbon-rc1-rc2-comparison-report.md: the two-run API-key comparison.
- ibm-carbon-rc1-rc2-unseen-comparison/report.md: the six-run theme/layer/disabled comparison.
- ibm-carbon-rc2-review.md: worked-example validation and rc.2 changes.
- ibm-carbon-focused-rerun-report.md: repaired baseline-versus-rc.1 comparison.
- ibm-carbon-focused-rerun/method/: separately repaired evaluator, suite, tests and method patch.

Canonical SHA-256 of the unchanged skill's relative-path-to-file-hash map:
768dfe2d099ced47cdee0106688cc3306f42a5b6215349afe8a1bcf6848c298a

The archive includes the plugin and these release notes; companion evaluation evidence remains separately delivered. No installation, publication, commit, push, pull request, merge or deployment is included.
