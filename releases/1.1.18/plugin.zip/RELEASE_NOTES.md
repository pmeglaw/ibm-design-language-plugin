# IBM Design Language 1.1.18

Published 1.1.17 strengthens real navigation destinations, observable supporting-action outcomes, nested narrow/RTL sizing, code scroll-owner keyboard checks and post-commit async focus recovery. Its fresh known practical generation failed with 9 pass, 2 fail and 0 untested; 320px containment/RTL remain deferred. Tested 390px and 1920px layouts fit. See [evaluation history](skills/ibm-design-language/references/evaluation-history.md#published-1117-practical-regression) for exact snapshot identity and limitations.

Version 1.1.18 refines agent entrypoint/routing, task-scaled review, source-review freshness and the Chrome-native scroll focus evidence boundary. These documentation edits have no new generation score. The prior practical result belongs to published 1.1.17; its historical ZIP and manifest remain unchanged. Package, CI, downloaded asset and installation checks are separate from behavioral evidence.

Version 1.1.15 introduced the sibling review-product-experience skill for IA/UI/UX review. Both skills preserve Carbon authority, approved product branding and separate source, rendered, assistive-technology and model-evaluation evidence. Structural/package tests are not product usability or accessibility certification.
